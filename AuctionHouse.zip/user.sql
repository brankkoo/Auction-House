ID,UserName,UserPass,IsAdmin
1,John,Doe,True
2,Mare,Mare,False
3,hi,kao,False
4,max,vin,False
5,branko,branko,False
6,toma,toma,False
