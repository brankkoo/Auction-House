ID,Name,Price,LastOffer,LastBidder,Time
1,Playstation5                                 ,499,503,John                                         ,558
2, xiaomi mi 11                                ,950,953,John                                         ,473
3,Ceral                                        ,8,8,admin                                        ,120
4,tea                                          ,3,3,admin                                        ,120
5,Coffe                                        ,1,1,admin                                        ,120
